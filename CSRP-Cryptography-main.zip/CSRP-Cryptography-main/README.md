# CSRP-Cryptography

This repo contains Python notebooks to be used in the student learning during the Cryptography module for the computer science rural pilot in spring of 2023. 

If you are a student, refer to your instructor's directions for how to import these notebooks into your JupyterHub server.

If you are an instructor, you should have admin rights to this repo such that you may push edits to the notebooks. 

